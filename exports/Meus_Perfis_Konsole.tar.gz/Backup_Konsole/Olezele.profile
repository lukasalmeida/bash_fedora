[Appearance]
BorderWhenActive=true
ColorScheme=MateriaDark
Font=JetBrains Mono NL Medium,11,-1,5,500,0,0,0,0,0,0,0,0,0,0,1,Regular,0,0
IgnoreWcWidth=false
TabActivityColor=128,64,0
TabColor=255,128,0
UseFontLineChararacters=false
WordMode=false

[Cursor Options]
CursorShape=2
CustomCursorColor=255,130,41
UseCustomCursorColor=true

[General]
Command=/bin/zsh
DimWhenInactive=false
Environment=TERM=xterm-256color,COLORTERM=truecolor
InheritContainerContext=false
InvertSelectionColors=false
Name=Olezele
Parent=FALLBACK/
SemanticHints=1
SemanticInputClick=false
TerminalCenter=false

[Terminal Features]
AnimatingCursorEnabled=true
BellMode=3
BlinkingCursorEnabled=false
